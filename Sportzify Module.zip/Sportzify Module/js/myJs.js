/* use script */
var app=angular.module("MyApp",[]);

app.service("MyService",function($http,$q)
{
var deferred=$q.defer();
$http.get('data/myJson.json').then(function(data)
{
deferred.resolve(data);
});
this.getItems=function()
{ return deferred.promise;
}
})
.controller("myCtrl",function($scope,MyService))
{
})